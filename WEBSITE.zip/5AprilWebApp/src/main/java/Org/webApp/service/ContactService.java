 package Org.webApp.service;
import java.sql.SQLException;
import java.util.List;

import Org.webApp.model.Contact;
import Org.webApp.repository.*;
public class ContactService 
{
  ContactRepository cr=new ContactRepository();

public int isContactSave(Contact c) throws SQLException, ClassNotFoundException
 {
   int b=cr.isSaveContact(c);
   return b;
 }
  public boolean isEmailPresent(String email)
  {
	  return cr.isEmailPresent(email);
  }
  public List<Contact>getAllContacts()
  {
	  return cr.getAllContacts();
  }
  public List<Contact> getUserDataBySearch(String data)
  {
	  return cr.getUserBySearch(data);
  }
}
