package Org.webApp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.webApp.model.Contact;
import Org.webApp.service.ContactService;


@WebServlet("/search")
public class searchServ extends HttpServlet {
	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		PrintWriter out=response.getWriter();
		String userData=request.getParameter("data");
		if(userData==null)
		{
		RequestDispatcher r=request.getRequestDispatcher("master.html");
		r.include(request, response);
		out.println("<input type='text' name='search' value='' placeholder='ENTER NAME OR CONTACT FOR SEARCH' style='width:50%;margin-left:340px;height:40px;' onkeyup='searchUser(this.value)'>");
		}
		response.setContentType("text/html");
		
		
		ContactService cs=new ContactService();
		List<Contact> list=cs.getAllContacts();	
	

		
		if(userData!=null)
		{
			list=cs.getUserDataBySearch(userData);
			
			
		}
		out.println("<html>"); 
		out.println("<head><title>I am Search and View</title></head>");
		out.println("<script src='js/validate.js' type='text/javascript'></script>");
		out.println("<body>");
		out.println("<div id='d'>");
		out.println("<br><br>");
		out.println("<table border='5' align='center' width='50%' height='50%'>");
		out.println("<tr><th>NAME</th><th>EMAIL</th><th>CONTACT</th><th>ADDRESS</th><th>DOB</th><th>DELETE</th><th>UPDATE</th></tr>");
		list.forEach((Contact)->out.println("<tr><td>"+Contact.getName()+"</td><td>"+Contact.getEmail()+"</td><td>"+Contact.getContact()+"</td><td>"+Contact.getAddress()+"</td><td>"+Contact.getDob()+"</td><td><a href=''>DELETE</a></td><td><a href=''>UPDATE</a></td></tr>"));
		out.println("</table>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
