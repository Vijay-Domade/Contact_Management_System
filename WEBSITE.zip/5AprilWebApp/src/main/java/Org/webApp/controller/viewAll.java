package Org.webApp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.webApp.model.Contact;
import Org.webApp.service.*;
import java.util.*;
@WebServlet("/view")
public class viewAll extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	ContactService cs=new ContactService();
	List<Contact> list=cs.getAllContacts();	
	RequestDispatcher r=request.getRequestDispatcher("master.html");
	r.include(request, response);
	out.println("<br><br>");
	out.println("<table border='5' align='center' width='50%' height='50%'>");
	out.println("<tr><th>NAME</th><th>EMAIL</th><th>CONTACT</th><th>ADDRESS</th><th>DOB</th><th>DELETE</th><th>UPDATE</th></tr>");
	for(Contact c:list)
	{
		out.println("<tr>");
		out.println("<td>"+c.getName()+"</td>");
		out.println("<td>"+c.getEmail()+"</td>");
		out.println("<td>"+c.getContact()+"</td>");
		out.println("<td>"+c.getAddress()+"</td>");
		out.println("<td>"+c.getDob()+"</td>");
		out.println("<td><a href=''>DELETE</a></td>");
		out.println("<td><a href=''>UPDATE</a></td>");
		out.println("</tr>");	
	}
	out.println("</table>");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
