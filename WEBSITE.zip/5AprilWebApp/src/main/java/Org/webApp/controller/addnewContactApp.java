package Org.webApp.controller;
import java.io.IOException;


import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Org.webApp.model.*;
import Org.webApp.service.*;
@WebServlet("/newcontact")
public class addnewContactApp extends HttpServlet
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>I am new contact</title>");
		out.println("<link  href='CSS/style.css' rel='stylesheet'/>");
		out.println("<script src='js/validate.js'type='text/javascript'></script>");
		out.println("</head>");
		RequestDispatcher r=request.getRequestDispatcher("master.html");
		r.include(request, response);
		out.println("<body>"); 
		out.println("<form name='frm' action='' method='POST'>");
		out.println("<input type='text' name='name' value='' placeholder='ENTER NAME' class='control' id='name' onkeyup='validateName(this.value)'/>&nbsp;<span id='s'></span><br><br>");
		out.println("<input type='text' name='email' value='' placeholder='ENTER EMAIL' class='control' onkeyup='validateEmail(this.value)' onblur='ajaxCall(this.value)'/>&nbsp;&nbsp;<span id='e'></span>&nbsp;&nbsp;<span id='e1'></span><br><br>");
		out.println("<input type='text' name='contact' value='' placeholder='ENTER CONTACT' class='control'  onkeyup='validateContact(this.value)'/>&nbsp;&nbsp;<span id='c'></span><br><br>");
		out.println("<input type='text' name='address' value='' placeholder='ENTER ADDRESS' class='control'/><br><br>");
		out.println("<input type='date' name='dob' value='' class='control'  onchange=' validateDob(this.value)'/>&nbsp;&nbsp;<span id='d'></span><br><br>");
		out.println("<input type='submit' name='s' value='Create New Contact' class='control'/><br><br>");
		out.println("</form>");
		
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String contact=request.getParameter("contact");
		String address=request.getParameter("address");
		String dob=request.getParameter("dob");
		
		Contact c=new Contact();
		c.setName(name);
		c.setEmail(email);
		c.setAddress(address);
		c.setContact(contact);
		c.setDob(dob);
		
		ContactService ct=new ContactService();
		try 
		{
			int result = ct.isContactSave(c);
			if(result==1)
			{
				out.println("<h1>New Contact Created..</h1>");
			}
			else if(result==-1)
			{
				out.println("<h1>Contact Already Exists...</h1>");
			}
			
			else if(result==0)
			{
				out.println(" ");
			}
			else
			{
				
			}
		}
		catch (Exception e) 
		{	
			out.println("Exception"+e);
		}
		out.println("</body>");
		out.println("</html>");
			
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
		doGet(request, response);
	}

}
