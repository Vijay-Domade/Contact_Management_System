package Org.webApp.controller;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Org.webApp.service.*;
@WebServlet("/verifyEmail")
public class verifyEmail extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	String email=request.getParameter("email");
	out.println(email);
	ContactService cs=new ContactService();
	/*
	boolean b=cs.isEmailPresent(email);
	if(b)
	{
		out.println("Email Already present in database");
	}
	else
	{
		out.println("Proper Email");	
	}*/
	out.println((cs.isEmailPresent(email)) ?"--Email already Present in Database":" ");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doGet(request, response);
	}

}
