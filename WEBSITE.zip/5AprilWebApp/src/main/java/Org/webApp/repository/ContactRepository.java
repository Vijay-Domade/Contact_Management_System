 package Org.webApp.repository;

import Org.webApp.model.Contact;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.*;
public class ContactRepository
{
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;	
	private List<Contact>list;
	//int x;
	public ContactRepository() 
	{
		try
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/n2","root","Vijay@sql123");
		}
		catch(Exception ex)
		{
			System.out.println("Exception"+ex);
		}
	}
	public int isSaveContact(Contact c) throws SQLException, ClassNotFoundException
	{
		
		try
		{
			
			PreparedStatement stmt=conn.prepareStatement("select *from phbook where email=? and contact=?");
			stmt.setString(1,c.getEmail());
			stmt.setString(2,c.getContact());
		    ResultSet rs=stmt.executeQuery();
			if(rs.next())
			{
				 return -1;        //-1 represents contact already presents
			}
		   //insert logic
		else
		{
		  stmt= conn.prepareStatement("insert into phbook values('0',?,?,?,?,?)");
		  stmt.setString(1,c.getName());
		  stmt.setString(2,c.getEmail());
		  stmt.setString(3,c.getContact());
		  stmt.setString(4,c.getAddress());
		  Date dob=Date.valueOf(c.getDob());
		  stmt.setDate(5,dob);
		  int value=stmt.executeUpdate();
		  if(value>0)
		  {
			  return 1; //represents data save in database
		  }
		  else
		  {
	          return 0; //represents data not save in database
		  }
	    }
		
	   }
		catch(Exception ex)
		{
			System.out.println("Error is"+ex);
			return 0;
		}
	 }
	 public boolean isEmailPresent(String email)
	 {
		 try
		 {
			 stmt=conn.prepareStatement("select *from phbook where email=?");
			 stmt.setString(1, email);
			 rs=stmt.executeQuery();
			 if(rs.next())
			 {
				 return true;
			 }
			 else
			 {
				 return false;
			 }
			 
		 }
		 catch(Exception ex)
		 {
			 System.out.println("Exception"+ex);
			 return false;
		 }
	 }
	 public List<Contact>getAllContacts()
	 {
		 try
		 {
			list=new ArrayList<Contact>();
			stmt=conn.prepareStatement("select *from phbook");
			rs=stmt.executeQuery();
			while(rs.next())
			{
				Contact c=new Contact();
				c.setId(rs.getInt(1));
				c.setName(rs.getString(2));
				c.setEmail(rs.getString(3));
				c.setContact(rs.getString(4));
				c.setAddress(rs.getString(5));
				c.setDob(rs.getString(6));
				list.add(c);
			}
		 }
		 catch(Exception ex)
		 {
			System.out.println("Error is"+ex); 
			return null;
		 }
		 return list;
	 }
	 public List<Contact> getUserBySearch(String data)
	 {
		 try
		 {
			 list=new ArrayList<Contact>();
				stmt=conn.prepareStatement("select *from phbook where name like '%"+data+"%' or contact like '%"+data+"%'");
				rs=stmt.executeQuery();
				while(rs.next())
				{
					Contact c=new Contact();
					c.setId(rs.getInt(1));
					c.setName(rs.getString(2));
					c.setEmail(rs.getString(3));
					c.setContact(rs.getString(4));
					c.setAddress(rs.getString(5));
					c.setDob(rs.getString(6));
					list.add(c);
				}
		 }
		 catch(Exception ex)
		 {
			 System.out.println("Error is"+ex);
			 return null;
		 }
		 return list;
	 }
	 
	 
		 
}
